package com.example.class02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Class02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
