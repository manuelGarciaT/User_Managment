package com.example.class02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Class02Application {

	public static void main(String[] args) {
		SpringApplication.run(Class02Application.class, args);
	}

}
